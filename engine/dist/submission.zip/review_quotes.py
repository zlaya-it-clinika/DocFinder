"""Validate the independent review's source quotations before using its answer."""
from __future__ import annotations

import re
from collections.abc import Iterable, Mapping

SUPPORT_HEADER = re.compile(r"SUPPORT\s*[:：]\s*([-—])?", re.IGNORECASE)
FIELD_HEADER = re.compile(r"^\s*\**\s*(KIND|ANSWER|MISSING|USED)\s*\**\s*[:：]", re.IGNORECASE | re.MULTILINE)
REVIEW_FIELDS = ("KIND", "ANSWER", "MISSING", "USED")
LABEL = re.compile(r"F\d+", re.IGNORECASE)
INLINE_LABELS = re.compile(r"\[\s*F\d+(?:\s*[,;]\s*F?\d+)*\s*\]", re.IGNORECASE)
MIN_QUOTE_LENGTH = 12


def _normalize(text: str) -> str:
    return " ".join(text.casefold().split())


def _complete_fields(answer: str) -> bool:
    fields = list(FIELD_HEADER.finditer(answer))
    if tuple(field.group(1).upper() for field in fields) != REVIEW_FIELDS:
        return False
    ends = [field.start() for field in fields[1:]] + [len(answer)]
    return all(answer[field.end():end].strip() for field, end in zip(fields, ends))


def validate_support(raw: str, used: Iterable[str], chunk_text_by_label: Mapping[str, str]) -> bool:
    """Require a complete review and a verbatim excerpt for every USED or inline citation."""
    lines = raw.strip().splitlines()
    header = SUPPORT_HEADER.fullmatch(lines[0].strip()) if lines else None
    if not header:
        return False

    supported = set()
    for index, line in enumerate(lines[1:], start=1):
        field = FIELD_HEADER.match(line)
        if field and field.group(1).upper() == "KIND":
            answer = "\n".join(lines[index:])
            if not _complete_fields(answer):
                return False
            required = {label.upper() for label in used}
            for match in INLINE_LABELS.finditer(answer):
                required.update(f"F{int(number)}" for number in re.findall(r"\d+", match.group()))
            return required <= supported
        if not line.strip():
            continue
        if header.group(1):
            return False
        label, separator, quote = line.partition("|")
        label = label.strip().upper()
        source = chunk_text_by_label.get(label)
        quote = _normalize(quote)
        if (not separator or not LABEL.fullmatch(label) or source is None
                or len(quote) < MIN_QUOTE_LENGTH or quote not in _normalize(source)):
            return False
        supported.add(label)
    return False
