"""Разбор ответа модели и проверка: нет ли чисел и ссылок, которых нет во фрагментах.

Выдуманный факт обнуляет оценку судьи, поэтому проверка строгая:
- каждое число ответа есть в использованных фрагментах, в сведениях о документах или в вопросе;
- каждая ссылка [Fn] существует;
- номера пунктов/статей («п. 3.1», «ст. 70») есть среди путей использованных фрагментов или в их тексте.
Логика сверки чисел перенесена из core/internal/grounding/numbers.go и расширена.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from decimal import Decimal, localcontext

KINDS = ("answer", "partial", "refusal", "correction", "clarify", "illegal", "out_of_scope")
TAG_RE = re.compile(r"^\s*\**\s*(KIND|ANSWER|MISSING|USED)\s*\**\s*[:：]\s*", re.IGNORECASE | re.MULTILINE)
LABEL_RE = re.compile(r"\[\s*(F\d+(?:\s*[,;]\s*F?\d+)*)\s*\]", re.IGNORECASE)

# Число: «450 000», «8 400 000», «0,1», «27 093». Пробелы-разделители тысяч склеиваются
NUMBER_RE = re.compile(r"(?<![\w.,])\d{1,3}(?:[ \u00a0\u202f]\d{3})+(?!\d)|(?<!\w)\d+(?:[.,]\d+)*")
LIST_MARKER = re.compile(r"(?m)(^|[;:]\s|\s)\d{1,2}\)\s")
REF_RE = re.compile(r"\b(п|пп|ч|ст|разд|подп)\.\s*(\d+(?:\.\d+)*)", re.IGNORECASE)
SCALE_RE = re.compile(r"(\d+(?:[.,]\d+)?)\s*(тыс|тысяч|млн|миллион\w*|млрд)")
SCALES = (("млрд", 1_000_000_000), ("млн", 1_000_000), ("миллион", 1_000_000), ("тыс", 1_000))

NUMBER_WORDS = {
    "один": "1", "одна": "1", "одно": "1", "одного": "1", "одной": "1", "одному": "1", "одним": "1", "одну": "1",
    "два": "2", "две": "2", "двух": "2", "двум": "2", "двумя": "2",
    "три": "3", "трех": "3", "трем": "3", "тремя": "3",
    "четыре": "4", "четырех": "4", "четырем": "4", "четырьмя": "4",
    "пять": "5", "пяти": "5", "пятью": "5", "шесть": "6", "шести": "6", "семь": "7", "семи": "7",
    "восемь": "8", "восьми": "8", "девять": "9", "девяти": "9", "десять": "10", "десяти": "10",
    "двенадцать": "12", "двенадцати": "12", "пятнадцать": "15", "пятнадцати": "15",
    "двадцать": "20", "двадцати": "20", "тридцать": "30", "тридцати": "30", "сорок": "40", "сорока": "40",
    "шестьдесят": "60", "шестидесяти": "60", "девяносто": "90", "девяноста": "90", "сто": "100",
    "первые": "1", "первых": "1", "полуторном": "1.5", "двойном": "2",
}
# Числа, которые не несут фактов: «1» (один из вариантов), «0»
HARMLESS = {"1", "0"}

# Узкая проверка записанного расчёта с процентом и явным знаком равенства.
# Числа из номеров пунктов, документов и дат не служат исходными данными.
CALC_NUMBER = r"\d+(?:[ \u00a0\u202f]\d{3})*(?:[.,]\d+)?"
CALC_SCALE = r"тыс\.?|тысяч\w*|млн\.?|миллион\w*|млрд\.?"
CALC_VALUE = rf"{CALC_NUMBER}(?:\s*(?:{CALC_SCALE}))?"
CALC_VALUE_RE = re.compile(rf"(?<![\w.,−-]){CALC_VALUE}(?!\w|[.,]\d)", re.I)
CALC_PERCENT_RE = re.compile(rf"(?<![\w.,−-])({CALC_NUMBER})\s*(?:%|процент\w*)", re.I)
CALC_TIMES = r"\s*(?:×|\*|·)\s*"
CALC_CURRENCY = r"(?:\s*(?:руб(?:лей|ля|ль|\.)?|₽))?"
CALC_BASE = rf"(?P<base>{CALC_VALUE})(?P<base_currency>{CALC_CURRENCY})"
CALC_RATE = rf"(?P<rate>{CALC_NUMBER})\s*%"
CALC_FACTOR = rf"(?P<factor>{CALC_NUMBER})(?:\s*(?:дней|дня|день))?"
CALC_RESULT = rf"\s*=\s*(?P<result>{CALC_VALUE})(?:(?P<result_percent>\s*%)|{CALC_CURRENCY})(?!\w|[.,]\d)"
CALC_PRODUCT_PATTERNS = tuple(
    re.compile(rf"(?<![\w.,]){product}{CALC_RESULT}", re.I)
    for product in (
        rf"{CALC_BASE}{CALC_TIMES}{CALC_RATE}(?:{CALC_TIMES}{CALC_FACTOR})?",
        rf"{CALC_RATE}{CALC_TIMES}{CALC_BASE}(?:{CALC_TIMES}{CALC_FACTOR})?",
        rf"{CALC_BASE}{CALC_TIMES}{CALC_FACTOR}{CALC_TIMES}{CALC_RATE}",
    )
)
CALC_PERCENT_CHANGE_RE = re.compile(
    rf"(?<![\w.,]){CALC_BASE}\s*(?P<operation>[+−-])\s*"
    rf"(?P<repeat>{CALC_VALUE}){CALC_CURRENCY}{CALC_TIMES}{CALC_RATE}{CALC_RESULT}", re.I)
CALC_METADATA_RE = re.compile(
    r"\b(?:ст|ч|п|пп|подп|разд|абз)\.\s*\d+(?:\.\d+)*|"
    r"\b(?:стать\w*|част[ьи]\w*|пункт\w*|подпункт\w*|раздел\w*|абзац\w*)\s+\d+(?:\.\d+)*|"
    r"\b[A-ZА-ЯЁ]{1,8}[-‑–]\d+(?:[/-]\d+)*|\b\d+[-‑–](?:ФЗ|ФКЗ)\b|"
    r"№\s*\d+(?:[/-]\d+)*|\b\d{1,2}[./-]\d{1,2}[./-]\d{4}\b|"
    r"\b\d{1,2}\s+(?:января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря)"
    r"\s+\d{4}\b|"
    r"\b(?:19|20)\d{2}\s*г(?:од\w*)?\.?|^\s*\d+(?:\.\d+)*\.\s+",
    re.I | re.M)


def _calculation_value(text: str) -> Decimal:
    number = re.match(CALC_NUMBER, text).group(0)
    value = Decimal(re.sub(r"[ \u00a0\u202f]", "", number).replace(",", "."))
    scale = text[len(number):].strip().lower()
    multiplier = next((factor for prefix, factor in SCALES if scale.startswith(prefix)), 1)
    sign, digits, exponent = value.as_tuple()
    scale_exponent = {1: 0, 1000: 3, 1000000: 6, 1000000000: 9}[multiplier]
    return Decimal((sign, digits, exponent + scale_exponent))


def _calculation_token(value: Decimal) -> str:
    token = format(value, "f")
    return token.rstrip("0").rstrip(".") if "." in token else token


def _calculation_results(answer: str, sources: list[str]) -> tuple[set[str], set[str]]:
    facts: set[Decimal] = set()
    rates: set[Decimal] = set()
    for source in sources:
        clean = CALC_METADATA_RE.sub(" ", source)
        rates.update(_calculation_value(match.group(1)) for match in CALC_PERCENT_RE.finditer(clean))
        clean = CALC_PERCENT_RE.sub(" ", clean)
        facts.update(_calculation_value(match.group(0)) for match in CALC_VALUE_RE.finditer(clean))

    supported: set[str] = set()
    invalid: set[str] = set()
    patterns = (*CALC_PRODUCT_PATTERNS, CALC_PERCENT_CHANGE_RE)
    matches = (match for pattern in patterns for match in pattern.finditer(answer))
    for match in matches:
        before = answer[:match.start()].rstrip()
        after = answer[match.end():].lstrip()
        # Не принимать подвыражение длинной формулы за весь расчёт.
        if (before and before[-1] in "+-−*/×·÷^") or (after and after[0] in "+-−*/×·÷^="):
            continue
        base = _calculation_value(match.group("base"))
        rate = _calculation_value(match.group("rate"))
        is_change = match.re is CALC_PERCENT_CHANGE_RE
        factor_text = None if is_change else match.group("factor")
        factor = _calculation_value(factor_text) if factor_text else Decimal(1)
        result = _calculation_value(match.group("result"))
        result_is_percent = bool(match.group("result_percent"))
        if result_is_percent and (is_change or factor_text or match.group("base_currency").strip()):
            invalid.add(_calculation_token(result))
            continue
        if is_change and _calculation_value(match.group("repeat")) != base:
            invalid.add(_calculation_token(result))
            continue
        operands = [(base, facts), (rate, rates)]
        if factor_text:
            operands.append((factor, facts))
        missing = {value for value, known in operands if value not in known}
        if missing:
            invalid.update(_calculation_token(value) for value in missing)
            continue
        with localcontext() as context:
            context.prec = max(28, sum(len(value.as_tuple().digits) for value, _ in operands) + 8)
            calculated = base * rate / Decimal(100) * factor
            if result_is_percent:
                calculated *= Decimal(100)
            if is_change:
                calculated = base + calculated if match.group("operation") == "+" else base - calculated
        if calculated == result:
            supported.update(numbers_in(match.group("result")))
        else:
            invalid.add(_calculation_token(result))
    return supported, invalid


@dataclass
class ModelAnswer:
    kind: str = "answer"
    text: str = ""
    missing: str = ""
    used: list[str] = field(default_factory=list)
    parsed: bool = False


def parse_answer(raw: str) -> ModelAnswer:
    parts: dict[str, str] = {}
    matches = list(TAG_RE.finditer(raw))
    for position, match in enumerate(matches):
        end = matches[position + 1].start() if position + 1 < len(matches) else len(raw)
        parts[match.group(1).upper()] = raw[match.end():end].strip()
    if "ANSWER" not in parts:
        # Модель ответила без формата: весь текст - ответ
        return ModelAnswer(text=raw.strip(), used=labels_in(raw), parsed=False)
    kind_raw = parts.get("KIND", "").strip().lower()
    kind = kind_raw.split()[0].strip(".,;") if kind_raw else "answer"
    kind = kind if kind in KINDS else "answer"
    missing = parts.get("MISSING", "").strip()
    if missing.strip(".").lower() in ("-", "—", "нет", "ничего", "none", ""):
        missing = ""
    used = labels_in(parts.get("USED", "")) or labels_in(parts["ANSWER"])
    return ModelAnswer(kind=kind, text=parts["ANSWER"].strip(), missing=missing, used=used, parsed=True)


def labels_in(text: str) -> list[str]:
    labels: list[str] = []
    for number in re.findall(r"F\s*(\d+)", text, re.IGNORECASE):
        label = f"F{int(number)}"
        if label not in labels:
            labels.append(label)
    return labels


def normalize_number(token: str) -> str:
    value = re.sub(r"[ \u00a0\u202f]", "", token).replace(",", ".").strip(".")
    if re.fullmatch(r"\d+\.0+", value):
        value = value.split(".")[0]
    if re.fullmatch(r"\d+", value):
        value = value.lstrip("0") or "0"
    return value


def _scaled(text: str) -> list[tuple[str, str]]:
    """«12 млн» -> ("12", "12000000")."""
    found = []
    for match in SCALE_RE.finditer(text.lower()):
        multiplier = next(value for prefix, value in SCALES if match.group(2).startswith(prefix))
        base = float(match.group(1).replace(",", "."))
        found.append((normalize_number(match.group(1)), normalize_number(str(int(round(base * multiplier))))))
    return found


def numbers_in(text: str) -> set[str]:
    cleaned = LABEL_RE.sub(" ", LIST_MARKER.sub(" ", text))
    found = {normalize_number(token) for token in NUMBER_RE.findall(cleaned)}
    for base, full in _scaled(cleaned):
        found.discard(base)
        found.add(full)
    return found


def source_numbers(sources: list[str]) -> set[str]:
    known: set[str] = set()
    for source in sources:
        known.update(normalize_number(token) for token in NUMBER_RE.findall(source))
        known.update(full for _, full in _scaled(source))
        for word in re.findall(r"[а-яё]+", source.lower().replace("ё", "е")):
            if word in NUMBER_WORDS:
                known.add(NUMBER_WORDS[word])
        # Номера документов «А-08/2024»: 8 и 2024
        for left, right in re.findall(r"[A-ZА-ЯЁ]{1,4}-(\d{1,4})[/-](\d{4})", source):
            known.update({normalize_number(left), right})
    # «3.2» подтверждает и первую часть «3» (пункт 3)
    known.update(value.split(".")[0] for value in list(known) if "." in value)
    return known


def unsupported_numbers(answer: str, sources: list[str]) -> list[str]:
    known = source_numbers(sources)
    calculated, invalid = _calculation_results(answer, sources)
    unsupported = numbers_in(answer) - known - calculated - HARMLESS
    return sorted(unsupported | invalid)


def unsupported_refs(answer: str, used_paths: list[str], used_texts: list[str]) -> list[str]:
    """Ссылки «п. 3.1» / «ст. 70», которых нет среди путей и текста использованных фрагментов."""
    allowed: set[str] = set()
    for source in used_paths + used_texts:
        allowed.update(re.findall(r"\d+(?:\.\d+)*", source))
    bad = []
    for kind, number in REF_RE.findall(answer):
        ref = f"{kind}. {number}"
        if number not in allowed and ref not in bad:
            bad.append(ref)
    return bad


def unknown_labels(answer: str, valid: set[str]) -> list[str]:
    labels = labels_in(" ".join(LABEL_RE.findall(answer)))
    return [label for label in labels if label not in valid]
